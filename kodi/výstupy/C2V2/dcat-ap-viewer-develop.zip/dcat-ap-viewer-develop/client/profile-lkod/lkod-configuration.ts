interface LkodConfiguration {

  dereferenceUrlPrefix: string;

}

declare var CONFIGURATION: LkodConfiguration;

export default CONFIGURATION;
