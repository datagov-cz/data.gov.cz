interface NkodConfiguration {

  dereferenceUrlPrefix: string;

  dcatApFormsUrl: string;

}

declare var CONFIGURATION: NkodConfiguration;

export default CONFIGURATION;
