package com.linkedpipes.etl.executor.api.v1.component.task;

/**
 * A single task that can be executed.
 */
public interface Task {

    String getIri();

}
