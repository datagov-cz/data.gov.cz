package com.linkedpipes.etl.executor.api.v1.vocabulary;

public final class SKOS {

    public static final String PREF_LABEL =
            "http://www.w3.org/2004/02/skos/core#prefLabel";

}
