#!/usr/bin/env bash

java -DconfigFileLocation=configuration.properties -jar ./executor/executor.jar
