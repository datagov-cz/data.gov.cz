#!/usr/bin/env bash

cd frontend
export configFileLocation=../configuration.properties
npm run start
cd ..