#!/usr/bin/env bash

java -DconfigFileLocation=configuration.properties -jar ./storage/storage.jar
