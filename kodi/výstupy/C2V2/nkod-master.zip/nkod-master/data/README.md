# Registrační záznamy z původního NKOD běžícího nad rejstříkovým řešením PVS
Tento repozitář obsahuje archiv registračních záznamů v původním NKOD běžícím nad rejstříkovým řešením PVS k 29.12.2017.

Z důvodu velikosti obsahuje pouze Rejstřík datových zdrojů (RDZ), konkrétně [měsíční indexy](rdz-monthindex-2017-12-29.zip) a [samotné záznamy](rdz-data-2017-12-29.zip).

Z [Portálu otevřených dat](https://data.gov.cz) si můžete stáhnout [Kompletní obsah NKOD včetně rejstříku Datových sad (228 MB)](http://opendata.gov.cz/_media/nkod-2017-12-29.zip) obsahující i záznamy harvestované z jednotlivých lokálních katalogů otevřených dat (LKODů) k 29.12.2017.

Tato data lze využít pro tvorbu aktuální podoby Národního katalogu otevřených dat.