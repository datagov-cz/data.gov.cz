import App from "./home.vue";
import {initializeApplication} from "./entry-point";

initializeApplication(App, "", []);
