/* eslint max-len: 0 */

export default {
  "noDataText": "Dotazu neodpovídají žádná data.",
  "optional": " (volitelné)",
};
