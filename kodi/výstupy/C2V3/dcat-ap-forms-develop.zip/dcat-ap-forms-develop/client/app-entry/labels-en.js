/* eslint max-len: 0 */

export default {
  "noDataText": "No data found.",
  "optional": " (optional)",
};
