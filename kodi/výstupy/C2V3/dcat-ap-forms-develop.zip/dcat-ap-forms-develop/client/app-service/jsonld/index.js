export {default as normalize} from "./normalization";
export {getDefaultGraphData} from "./graphs";
export {getByType, getByIri} from "./entities";
export {getId, getTypes, getValue, getValues} from "./properties";