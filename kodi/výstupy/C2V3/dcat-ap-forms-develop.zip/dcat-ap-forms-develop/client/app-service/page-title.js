export default function setPageTitle(title) {
  document.title = title;
}