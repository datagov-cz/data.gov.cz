import {
  apply,
  provided,
  url,
  email,
  applyArray,
} from "../app-service/validators";

export function createCatalog() {
  return {
    "title_cs": "",
    "title_en": "",
    "iri": undefined,
    "endpoint": "",
    "contact_point_name": "",
    "contact_point_email": "",
    "homepage": "",
    "type": undefined,
    "$validators": {
      "force": false,
    },
  };
}

export function createCatalogValidators() {
  return {
    "err_title_cs": apply(
      (t) => t.catalog, "title_cs",
      provided,
      "catalog_title_missing"),
    "err_endpoint": applyArray(
      (t) => t.catalog, "endpoint",
      [
        [provided, "catalog_url_missing"],
        [url, "catalog_url_invalid"],
      ]),
    "err_contact_point_email": applyArray(
      (t) => t.catalog, "contact_point_email",
      [
        [provided, "catalog_contact_point_email_missing"],
        [email, "catalog_contact_point_email_invalid"],
      ]),
    "err_contact_point_name": applyArray(
      (t) => t.catalog, "contact_point_name",
      [
        [provided, "catalog_contact_point_name_missing"],
      ]),
    "err_homepage": applyArray(
      (t) => t.catalog, "homepage",
      [
        [url, "homepage_invalid"],
      ]),
    "err_catalog_type": apply(
      (t) => t.catalog, "type",
      provided,
      "catalog_type_missing"),
  };
}

export function isCatalogValid(catalog) {
  return provided(catalog.title_cs) &&
    provided(catalog.endpoint) &&
    url(catalog.endpoint) &&
    provided(catalog.contact_point_email) &&
    provided(catalog.contact_point_name) &&
    email(catalog.contact_point_email) &&
    url(catalog.homepage) &&
    provided(catalog.type);
}
