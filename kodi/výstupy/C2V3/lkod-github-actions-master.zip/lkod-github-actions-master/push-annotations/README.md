## Configuration


## Input file format
The input file should be JSON lines, i.e. one JSON object on each line.
Each JSON should have following properties:
 * path
 * start_line
 * end_line
 * start_column
 * end_column
 * annotation_level
 * message
 * title