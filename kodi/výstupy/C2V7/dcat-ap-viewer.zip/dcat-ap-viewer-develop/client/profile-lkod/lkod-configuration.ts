interface LkodConfiguration {

  dereferenceUrlPrefix: string;

  yasguiUrl: string;

  yasguiDefaultQuery: string;

  semanticBrowser: string;

  semanticVisualisation: string;

}

declare var CONFIGURATION: LkodConfiguration;

export default CONFIGURATION;
