import {Keyword} from "../../data-model/keyword";

export interface ColoredKeyword extends Keyword {

  color: string;

}