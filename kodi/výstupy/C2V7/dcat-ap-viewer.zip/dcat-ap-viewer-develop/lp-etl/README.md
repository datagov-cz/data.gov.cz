# LinkedPipes : ETL
Defined transformations and test data used by
[LinkedPipes : ETL](https://github.com/linkedpipes/etl)
to prepare data for this project.