#!/usr/bin/env bash

java -DconfigFileLocation=configuration.properties -jar ./executor-monitor/executor-monitor.jar
