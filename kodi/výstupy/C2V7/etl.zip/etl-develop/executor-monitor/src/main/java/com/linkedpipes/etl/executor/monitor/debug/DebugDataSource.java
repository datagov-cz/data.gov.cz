package com.linkedpipes.etl.executor.monitor.debug;

public interface DebugDataSource {

    DebugData getDebugData(String iri);

}
