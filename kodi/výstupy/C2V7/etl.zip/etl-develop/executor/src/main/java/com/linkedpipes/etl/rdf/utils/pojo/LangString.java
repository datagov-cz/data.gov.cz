package com.linkedpipes.etl.rdf.utils.pojo;

public interface LangString {

    void setValue(String value, String language);

}
