package com.linkedpipes.etl.rdf.utils.vocabulary;

public final class DCTERMS {

    public static final String DESCRIPTION =
            "http://purl.org/dc/terms/description";

}
