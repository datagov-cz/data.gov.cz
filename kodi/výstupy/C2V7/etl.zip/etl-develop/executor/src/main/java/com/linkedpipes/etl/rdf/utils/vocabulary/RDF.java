package com.linkedpipes.etl.rdf.utils.vocabulary;

public final class RDF {

    public static final String TYPE =
            "http://www.w3.org/1999/02/22-rdf-syntax-ns#type";

}
