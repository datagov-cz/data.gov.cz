package com.linkedpipes.etl.rdf.utils.vocabulary;

public final class SKOS {

    public static final String PREF_LABEL =
            "http://www.w3.org/2004/02/skos/core#prefLabel";

    public static final String NOTE =
            "http://www.w3.org/2004/02/skos/core#note";


}
