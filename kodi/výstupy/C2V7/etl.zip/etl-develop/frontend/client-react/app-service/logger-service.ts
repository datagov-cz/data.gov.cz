
export const logger = {
  "info": console.info,
  "error": console.error,
  "warning": console.warn,
};
