import DebugView from "./debug-view";
export default DebugView;
