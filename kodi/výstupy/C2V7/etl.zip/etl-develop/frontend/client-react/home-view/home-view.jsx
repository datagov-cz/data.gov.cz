import React from "react";
import Button from "@mui/material/Button";

export default function App() {
  return <Button variant="contained">Home</Button>;
}
