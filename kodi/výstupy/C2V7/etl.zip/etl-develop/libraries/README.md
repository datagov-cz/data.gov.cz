# Libraries
This project contain libraries with shared code. 
The code can be shared only by the backend of the LP:ETL not the plugins.
