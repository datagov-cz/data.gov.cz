/**
 * This package is special version of an adapter it is designed to convert
 * raw data object of arbitrary version to object of the current version.
 *
 * Migration is done in-place using the raw object.
 */
package com.linkedpipes.etl.library.pipeline.migration;
