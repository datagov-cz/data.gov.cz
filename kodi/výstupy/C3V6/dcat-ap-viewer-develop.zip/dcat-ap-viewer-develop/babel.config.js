module.exports = (api) => {

  api.cache.using(() => process.env.NODE_ENV);

  const presets = [
    "@babel/preset-react",
    "@babel/preset-typescript",
    ["@babel/preset-env", {
      "useBuiltIns": "usage",
      "corejs": {
        "version": "3.8",
        "proposals": true,
      },
    }],
  ];

  const plugins = [];
  if (api.env(["development"])) {
    plugins.push("react-hot-loader/babel");
  }

  return {
    "presets": presets,
    "plugins": plugins,
    "ignore": [
      /node_modules/
    ],
  };
};