# API implementation for NKOD
NKDO specific implementation of client API.
