# DCAT-AP 2 based model definition
Definition of basic data objects used in this project.
