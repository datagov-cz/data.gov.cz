export type LanguageString = Record<string, string>;
