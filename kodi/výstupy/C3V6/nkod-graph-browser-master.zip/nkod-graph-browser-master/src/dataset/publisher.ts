import {Entity} from "../core/entity";

export class Publisher extends Entity {}
