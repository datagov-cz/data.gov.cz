import {Entity} from "../core/entity";

export class OntologyAttribute extends Entity {}
