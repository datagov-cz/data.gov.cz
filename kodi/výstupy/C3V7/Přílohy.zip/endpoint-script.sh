#!/bin/sh

var="$(curl https://data.gov.cz/sparql --data query=PREFIX%20dcterms%3A%20%3Chttp%3A%2F%2Fpurl.org%2Fdc%2Fterms%2F%3E%0APREFIX%20dcat%3A%20%3Chttp%3A%2F%2Fwww.w3.org%2Fns%2Fdcat%23%3E%0APREFIX%20rdf%3A%20%3Chttp%3A%2F%2Fwww.w3.org%2F1999%2F02%2F22-rdf-syntax-ns%23%3E%0APREFIX%20rdfs%3A%20%3Chttp%3A%2F%2Fwww.w3.org%2F2000%2F01%2Frdf-schema%23%3E%0A%0ASELECT%20DISTINCT%20%3Fendpoint%20%0AWHERE%20%7B%0A%20%20%20%20%3Fdataset%20a%20dcat%3ADataset%20%3B%0A%20%20dcterms%3Atitle%20%3Ftitle%20%3B%0A%20%20dcat%3Adistribution%2Fdcat%3AaccessService%20%3Fservice%20.%0A%20%20%20%20%3Fservice%20a%20dcat%3ADataService%20%3B%0A%20%20dcterms%3AconformsTo%20%3Chttps%3A%2F%2Fwww.w3.org%2FTR%2Fsparql11-protocol%2F%3E%20%3B%0A%20%20dcat%3AendpointURL%20%3Fendpoint%20.%0A%20%20%20%20FILTER%28langMatches%28LANG%28%3Ftitle%29%2C%20%22cs%22%29%29%0A%7D \
 -X POST \
 | grep '<uri>'| grep -oP '(?<=\<uri\>).*?(?=\</uri\>)')"

for address in $var
do
  name="endpoint-$(echo $address | tr ':/.\?<>|" ' -)"

  echo "address = \"$address\""
  echo "name = \"$name\""
  curl localhost:8080/api/configs -o - -X PUT \
   -H 'Content-Type: application/json' \
   --data '{
                           "incrementally": true,
                           "schedule": {
                                  "schedule": "0 40 3 * * *",
                                  "automatic": true
                           },
                           "config": {
                                  "type": "eeaRDF",
                                  "eeaRDF": {
                                         "endpoint": "'$address'",
                                         "query": [
                                                "PREFIX dqv: <http://www.w3.org/ns/dqv#>\nPREFIX sdmxdim: <http://purl.org/linked-data/sdmx/2009/dimension#>\nPREFIX dcterms: <http://purl.org/dc/terms/>\nPREFIX dcat: <http://www.w3.org/ns/dcat#>\nPREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nPREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\nPREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n\nCONSTRUCT{\n  ?s dqv:value ?count;\n    a ?class;\n    dqv:computedOn ?endpoint;\n    sdmxdim:refPeriod ?date.\n} WHERE{\n  {\n    SELECT DISTINCT ?class (COUNT(?sub) AS ?count)\n    WHERE {\n      ?sub a ?class .\n    } GROUP BY ?class \n  }\n  BIND(xsd:date(now()) as ?date)\n  BIND(<'$address'> as ?endpoint)\n  BIND(iri(concat(?endpoint,\"/\",?date,\"/\",?class)) as ?s)\n}",
                                                "PREFIX dqv: <http://www.w3.org/ns/dqv#>\nPREFIX sdmxdim: <http://purl.org/linked-data/sdmx/2009/dimension#>\nPREFIX dcterms: <http://purl.org/dc/terms/>\nPREFIX dcat: <http://www.w3.org/ns/dcat#>\nPREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>\nPREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>\nPREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n\nCONSTRUCT{\n  ?s dqv:value ?count;\n    dqv:isMeasurementOf ?predicate;\n    dqv:computedOn ?endpoint;\n    sdmxdim:refPeriod ?date.\n} WHERE{\n  {SELECT DISTINCT ?predicate (COUNT(?sub) AS ?count)\n    WHERE {\n      ?sub ?predicate ?o .\n    } GROUP BY ?predicate \n  }\n  BIND(xsd:date(now()) as ?date)\n  BIND(<'$address'> as ?endpoint)\n  BIND(iri(concat(?endpoint,\"/\",?date,\"/\",?predicate)) as ?s)\n}"
                                         ],
                                         "queryType": "construct"
                                  },
                                  "syncReq": {},
                                  "index": {
                                         "index": "'$name'",
                                         "type": "rdf"
                                  }
                           }
                    }'
  echo ""

done