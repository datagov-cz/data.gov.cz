This directory contains operations considered as one-step operations from data designer point of view. These operations
are not atomic nor working with one model, yet as simple as possible for a user.
