manager
=======

Please use the [build instructions from the editor](../editor/README.md). The apps are similar in structure.
