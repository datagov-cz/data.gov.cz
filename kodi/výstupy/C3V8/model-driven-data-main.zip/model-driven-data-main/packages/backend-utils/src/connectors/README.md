# Connectors

Classes in this directory are used to communicate with the backend server. Their
purpose is to abstract away the communication protocol details between the
client-side and the server-side.

## Future work

The connector interface should be moved into the core package when SOLID support is implemented, as both SOLID pods and backed service should be treated similarly.
