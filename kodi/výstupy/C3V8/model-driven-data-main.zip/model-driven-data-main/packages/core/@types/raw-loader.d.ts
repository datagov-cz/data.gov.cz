declare module "*.sparql" {
    const contents: string;
    export = contents
}
