@dataspecer/core
================

This package groups several core functionalities of Dataspecer.

Please see [individual directories](./src/) for detailed documentation.
