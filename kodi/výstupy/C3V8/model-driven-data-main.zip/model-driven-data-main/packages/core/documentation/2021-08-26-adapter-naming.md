# Adapter naming
Adapter is a class, or a method that convert data from input type to output type.
The name of the adapter method, or class member method must adhere to following pattern ```{from}To{To}```.
For example adapter from RDF to ObjectModel should be named ```rdfToObjectModel```.
