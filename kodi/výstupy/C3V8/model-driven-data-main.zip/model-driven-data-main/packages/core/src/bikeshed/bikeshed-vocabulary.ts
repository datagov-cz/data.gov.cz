export const BIKESHED = {
  Generator: "http://example.com/generator/bikeshed",
};
