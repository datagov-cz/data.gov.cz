# About

Represents a conceptual model, as loaded from PIM.
The objective is to make work with PIM model easier compare to working with raw representation in PIM.
