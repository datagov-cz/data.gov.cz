# About

Defines core objects used by rest of the repository.
