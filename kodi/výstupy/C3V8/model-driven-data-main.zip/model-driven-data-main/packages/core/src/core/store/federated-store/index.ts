export { ReadOnlyFederatedStore } from "./read-only-federated-store";
