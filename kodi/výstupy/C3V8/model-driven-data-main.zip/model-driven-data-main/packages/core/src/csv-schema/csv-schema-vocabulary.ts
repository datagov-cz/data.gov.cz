export const CSV_SCHEMA = {
    "Generator": "http://example.com/generator/csv-schema",
}
