# About

Data platform specific model (data-psm) level represent model on a platform specific level.
It can represent, for example, a specific file format.

The PSM level classes does not automatically have all properties of their PIM interpretations.
They need to be added explicitly.
