# About

Implement input/output functionality.
As the code must be executable in the browser as well as using NodeJs, no direct input/output primitive must be used in the code.
Instead, abstraction from this package must be used.
