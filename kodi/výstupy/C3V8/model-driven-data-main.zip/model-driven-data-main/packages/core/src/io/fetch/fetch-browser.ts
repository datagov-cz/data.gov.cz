// @ts-ignore
export const httpFetch = fetch;
