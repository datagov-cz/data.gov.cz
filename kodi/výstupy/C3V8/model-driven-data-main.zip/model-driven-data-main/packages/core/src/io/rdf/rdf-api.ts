export * from "../../core/adapter/rdf/rdf-api";
