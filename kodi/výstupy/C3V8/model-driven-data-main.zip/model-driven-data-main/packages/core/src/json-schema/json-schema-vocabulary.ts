export const JSON_SCHEMA = {
  Generator: "http://example.com/generator/json-schema",
};
