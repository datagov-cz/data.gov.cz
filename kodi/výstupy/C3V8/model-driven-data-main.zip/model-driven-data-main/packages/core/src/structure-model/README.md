# About

Represents a structural model, as loaded from PSM.
The objective is to make work with PSM model easier compare to working with raw representation in PSM.
This model does not load nor interpret any values from PIM level.
