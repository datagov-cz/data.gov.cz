# About

This module holds definitions of well known and established vocabularies and external data definitions.
