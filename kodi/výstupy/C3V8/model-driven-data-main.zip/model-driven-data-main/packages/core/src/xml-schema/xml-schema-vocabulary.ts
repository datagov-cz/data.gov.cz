export const XML_SCHEMA = {
  Generator: "http://example.com/generator/xml-schema",
};
