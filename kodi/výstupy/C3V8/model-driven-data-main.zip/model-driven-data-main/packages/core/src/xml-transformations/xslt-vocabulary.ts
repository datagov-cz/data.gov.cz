export const XSLT_LIFTING = {
  Generator: "http://example.com/generator/xslt-lifting",
};

export const XSLT_LOWERING = {
  Generator: "http://example.com/generator/xslt-lowering",
};
