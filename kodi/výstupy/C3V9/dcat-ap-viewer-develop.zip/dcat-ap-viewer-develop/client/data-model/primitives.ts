/**
 * Represent a string in multiple languages.
 */
export type Literal = { [language: string]: string };
