interface LkodConfiguration {

  dereferenceUrlPrefix: string;

  yasguiUrl: string;

  yasguiDefaultQuery: string;

}

declare var CONFIGURATION: LkodConfiguration;

export default CONFIGURATION;
