interface NkodConfiguration {

  dereferenceUrlPrefix: string;

  dcatApFormsUrl: string;

  dashboardsUrlTemplate: string;

  dashboardsDetailedUrlTemplate: string;

}

declare var CONFIGURATION: NkodConfiguration;

export default CONFIGURATION;
