module.exports = {
  "globals": {
    "module": false,
    "process": false,
    "__dirname": false,
  },
};
